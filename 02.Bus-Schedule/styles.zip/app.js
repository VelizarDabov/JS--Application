function solve() {

let btnDepart = document.getElementById('depart')
btnDepart.style.disabled = false
const btnArrive = document.getElementById('arrive')
const url = 'http://localhost:3030/jsonstore/bus/schedule/'

   async function depart() {
     const response = await fetch(url);
     const data = await response.json();
     btnDepart.disabled = true;
     btnArrive.disabled = false;
     document.querySelector(".info").textContent = 'Next stop Depot';

    }

   async function arrive() {
    btnDepart.disabled = false;
    btnArrive.disabled = true;
    document.querySelector(".info").textContent = 'Arriving at Depot';
    }

    return {
        depart,
        arrive
    };
}

let result = solve();

// async function getInfo() {
//     const stopInfoElement = document.getElementById('stopId');
//     let stopId = stopInfoElement.value;
//     const url = `http://localhost:3030/jsonstore/bus/businfo/${stopId}`;
//     let stopNameElement = document.getElementById('stopName');

//     let busList = document.getElementById('buses')

//     busList.innerHTML = '';
//     stopInfoElement.value = '';

//     try {
//         const response = await fetch(url);
//         const data = await response.json();

//         stopNameElement.textContent = data.name;
//         Object.entries(data.buses).forEach(([busNumber, timeArrive]) => {

//             const li = document.createElement('li');
//             li.textContent = `Bus ${busNumber} arrives in ${timeArrive} minutes`;
//             busList.appendChild(li)
//         })
//     } catch (error) {
//         stopNameElement.textContent = 'Error'
//     }

// }